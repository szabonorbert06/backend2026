<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up() {
        Schema::create('types', function (Blueprint $table) {
            $table->id();
            $table->foreignId('group_id')->constrained('groups');
            $table->string('name', 50);
            $table->integer('speed');
            $table->integer('height');
            $table->integer('weight');
            $table->string('origin');
            $table->integer('lifetime');
            $table->string('colors');
            $table->timestamps();
        });
    }

    public function down() {
        Schema::dropIfExists('types');
    }
};
