<?php

namespace Database\Seeders;
use Illuminate\Database\Seeder;
use App\Models\Type;

class TypeSeeder extends Seeder {
    public function run() {
        Type::create(['group_id' => 1, 'name' => 'Puli', 'speed' => 35, 'height' => 40, 'weight' => 13, 'origin' => 'Magyarország', 'lifetime' => 14, 'colors' => 'Fekete']);
        Type::create(['group_id' => 1, 'name' => 'Német juhászkutya', 'speed' => 48, 'height' => 60, 'weight' => 35, 'origin' => 'Németország', 'lifetime' => 12, 'colors' => 'Fekete-barna']);
    }
}
