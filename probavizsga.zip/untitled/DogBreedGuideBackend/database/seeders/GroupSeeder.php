<?php

namespace Database\Seeders;
use Illuminate\Database\Seeder;
use App\Models\Group;

class GroupSeeder extends Seeder {
    public function run() {
        Group::create(['name' => 'Pásztorkutyák', 'visible' => true]);
        Group::create(['name' => 'Vadászkutyák', 'visible' => true]);
        Group::create(['name' => 'Nem látható csoport', 'visible' => false]);
    }
}
