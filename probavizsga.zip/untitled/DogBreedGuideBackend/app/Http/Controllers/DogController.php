<?php

namespace App\Http\Controllers;

use App\Models\Group;
use App\Models\Type;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class DogController extends Controller {
    public function getGroups() {
        return response()->json(Group::all());
    }

    public function getTypes() {
        return response()->json(Type::all());
    }

    public function getTypeById($id) {
        $type = Type::find($id);
        if (!$type) {
            return response()->json(['message' => 'Hiba: Nincs ilyen fajta!'], 404);
        }
        return response()->json($type);
    }

    public function storeType(Request $request) {
        $validator = Validator::make($request->all(), [
            'group_id' => 'required|exists:groups,id',
            'name'     => 'required|string|max:50',
            'speed'    => 'required|integer|min:1|max:70',
            'height'   => 'required|integer',
            'weight'   => 'required|integer|min:1|max:100',
            'origin'   => 'required|string|max:255',
            'lifetime' => 'required|integer|min:1|max:25',
            'colors'   => 'required|string|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $type = Type::create($request->all());
        return response()->json($type, 201);
    }
}
