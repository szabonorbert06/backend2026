<?php

use App\Models\Group;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    $groups = Group::where('visible', true)->with('types')->get();
    return view('breeds', compact('groups'));
});
