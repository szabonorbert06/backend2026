<?php

use App\Http\Controllers\DogController;
use Illuminate\Support\Facades\Route;

Route::get('/groups', [DogController::class, 'getGroups']);
Route::get('/types', [DogController::class, 'getTypes']);
Route::get('/types/{id}', [DogController::class, 'getTypeById']);
Route::post('/types', [DogController::class, 'storeType']);
